-- Dumping tables for database: `drugs_ordering_db`


SET FOREIGN_KEY_CHECKS=0; 


-- Dumping structure for table: `bill_no`

DROP TABLE IF EXISTS `bill_no`;
CREATE TABLE `bill_no` (
  `bill_id` int(10) NOT NULL AUTO_INCREMENT,
  `cus_id` int(10) NOT NULL,
  `bill_no` int(10) NOT NULL DEFAULT '0',
  `bill_status` int(2) NOT NULL DEFAULT '0' COMMENT '0 == Not complete bill // 1== complete bill',
  PRIMARY KEY (`bill_id`),
  UNIQUE KEY `cus_id` (`cus_id`) USING BTREE,
  KEY `bill_no` (`bill_no`),
  CONSTRAINT `cus_id` FOREIGN KEY (`cus_id`) REFERENCES `customer_details` (`cus_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: bill_no

INSERT INTO `bill_no` VALUES('42', '1', '10', '1');
INSERT INTO `bill_no` VALUES('43', '2', '8', '1');
INSERT INTO `bill_no` VALUES('44', '6', '1', '0');
INSERT INTO `bill_no` VALUES('45', '13', '1', '0');
INSERT INTO `bill_no` VALUES('46', '14', '4', '1');
INSERT INTO `bill_no` VALUES('47', '15', '2', '1');


-- Dumping structure for table: `customer_added_item`

DROP TABLE IF EXISTS `customer_added_item`;
CREATE TABLE `customer_added_item` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cus_id` int(10) NOT NULL,
  `bill_no` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `item_qty` double(10,2) NOT NULL,
  `pay_status` int(2) NOT NULL DEFAULT '0' COMMENT 'No pay == 0 // payied == 1',
  `item_add_date` date NOT NULL,
  `item_add_time` time NOT NULL,
  `item_save_status` tinyint(2) NOT NULL DEFAULT '5' COMMENT '5== save item // 7 == add to buy // 3== pay finished',
  PRIMARY KEY (`id`),
  KEY `bill_no` (`bill_no`),
  KEY `cus_id_cus_deatails` (`cus_id`),
  CONSTRAINT `cus_id_cus_deatails` FOREIGN KEY (`cus_id`) REFERENCES `customer_details` (`cus_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: customer_added_item

INSERT INTO `customer_added_item` VALUES('56', '1', '1', '33', '8.00', '1', '2019-08-23', '06:01:23', '3');
INSERT INTO `customer_added_item` VALUES('61', '1', '1', '11', '2.00', '1', '2019-08-23', '06:01:23', '3');
INSERT INTO `customer_added_item` VALUES('62', '1', '2', '26', '2.00', '1', '2019-08-23', '06:02:19', '3');
INSERT INTO `customer_added_item` VALUES('68', '1', '2', '33', '1.00', '1', '2019-08-24', '12:42:42', '3');
INSERT INTO `customer_added_item` VALUES('69', '1', '2', '31', '1.00', '1', '2019-08-24', '12:42:45', '3');
INSERT INTO `customer_added_item` VALUES('73', '1', '3', '4', '3.00', '1', '2019-08-24', '12:57:26', '3');
INSERT INTO `customer_added_item` VALUES('75', '1', '3', '26', '1.00', '1', '2019-08-24', '12:57:31', '3');
INSERT INTO `customer_added_item` VALUES('77', '1', '4', '26', '2.00', '1', '2019-08-24', '06:19:38', '3');
INSERT INTO `customer_added_item` VALUES('78', '6', '1', '33', '1.00', '0', '2019-08-28', '01:17:36', '7');
INSERT INTO `customer_added_item` VALUES('79', '6', '0', '31', '3.00', '0', '2019-08-28', '01:17:36', '5');
INSERT INTO `customer_added_item` VALUES('80', '6', '0', '29', '2.00', '0', '2019-08-28', '01:17:36', '5');
INSERT INTO `customer_added_item` VALUES('81', '13', '0', '31', '2.00', '0', '2019-08-28', '09:11:12', '5');
INSERT INTO `customer_added_item` VALUES('82', '13', '0', '29', '1.00', '0', '2019-08-28', '09:11:12', '5');
INSERT INTO `customer_added_item` VALUES('84', '13', '0', '29', '1.00', '0', '2019-08-28', '09:31:39', '5');
INSERT INTO `customer_added_item` VALUES('90', '13', '0', '9', '1.00', '0', '2019-08-28', '10:17:40', '5');
INSERT INTO `customer_added_item` VALUES('95', '14', '0', '9', '2.00', '0', '2019-08-28', '11:17:42', '5');
INSERT INTO `customer_added_item` VALUES('96', '14', '1', '22', '1.00', '1', '2019-08-28', '11:17:42', '3');
INSERT INTO `customer_added_item` VALUES('97', '14', '1', '29', '1.00', '1', '2019-08-28', '11:17:42', '3');
INSERT INTO `customer_added_item` VALUES('98', '14', '2', '31', '2.00', '1', '2019-08-28', '11:22:24', '3');
INSERT INTO `customer_added_item` VALUES('99', '14', '2', '29', '1.00', '1', '2019-08-28', '11:44:01', '3');
INSERT INTO `customer_added_item` VALUES('100', '14', '0', '11', '1.00', '0', '2019-08-28', '11:46:14', '5');
INSERT INTO `customer_added_item` VALUES('101', '14', '0', '34', '1.00', '0', '2019-08-28', '11:46:19', '5');
INSERT INTO `customer_added_item` VALUES('102', '14', '0', '5', '1.00', '0', '2019-08-28', '11:47:03', '5');
INSERT INTO `customer_added_item` VALUES('103', '14', '0', '22', '1.00', '0', '2019-08-28', '11:47:05', '5');
INSERT INTO `customer_added_item` VALUES('104', '14', '0', '33', '1.00', '0', '2019-08-28', '11:55:47', '5');
INSERT INTO `customer_added_item` VALUES('105', '14', '3', '31', '1.00', '1', '2019-08-28', '11:55:47', '3');
INSERT INTO `customer_added_item` VALUES('106', '14', '3', '9', '2.00', '1', '2019-08-28', '11:55:47', '3');
INSERT INTO `customer_added_item` VALUES('107', '14', '3', '26', '1.00', '1', '2019-08-28', '11:55:47', '3');
INSERT INTO `customer_added_item` VALUES('109', '15', '1', '31', '1.00', '1', '2019-08-29', '12:00:09', '3');
INSERT INTO `customer_added_item` VALUES('110', '15', '1', '33', '1.00', '1', '2019-08-29', '12:00:09', '3');
INSERT INTO `customer_added_item` VALUES('111', '15', '0', '31', '1.00', '0', '2019-08-29', '12:02:24', '5');
INSERT INTO `customer_added_item` VALUES('112', '15', '2', '9', '1.00', '0', '2019-08-29', '12:03:05', '7');
INSERT INTO `customer_added_item` VALUES('113', '15', '0', '33', '1.00', '0', '2019-08-29', '12:03:09', '5');
INSERT INTO `customer_added_item` VALUES('116', '1', '5', '31', '2.00', '1', '2019-09-02', '06:20:35', '3');
INSERT INTO `customer_added_item` VALUES('120', '1', '0', '31', '2.00', '0', '2019-09-03', '10:04:09', '5');
INSERT INTO `customer_added_item` VALUES('124', '1', '6', '5', '4.00', '1', '2019-09-03', '10:05:05', '3');
INSERT INTO `customer_added_item` VALUES('125', '1', '6', '11', '1.00', '1', '2019-09-03', '10:05:11', '3');
INSERT INTO `customer_added_item` VALUES('126', '1', '6', '34', '1.00', '1', '2019-09-03', '12:19:39', '3');
INSERT INTO `customer_added_item` VALUES('127', '1', '7', '29', '2.00', '1', '2019-09-03', '01:31:31', '3');
INSERT INTO `customer_added_item` VALUES('128', '1', '7', '11', '1.00', '1', '2019-09-03', '01:31:32', '3');
INSERT INTO `customer_added_item` VALUES('129', '1', '7', '4', '1.00', '1', '2019-09-03', '01:31:33', '3');
INSERT INTO `customer_added_item` VALUES('130', '1', '9', '34', '1.00', '1', '2019-09-03', '01:31:34', '3');
INSERT INTO `customer_added_item` VALUES('131', '1', '8', '11', '1.00', '1', '2019-09-03', '01:43:17', '3');
INSERT INTO `customer_added_item` VALUES('132', '1', '8', '35', '1.00', '1', '2019-09-03', '01:43:18', '3');
INSERT INTO `customer_added_item` VALUES('133', '1', '8', '22', '1.00', '1', '2019-09-03', '01:43:19', '3');
INSERT INTO `customer_added_item` VALUES('134', '1', '8', '9', '1.00', '1', '2019-09-03', '01:43:20', '3');
INSERT INTO `customer_added_item` VALUES('135', '1', '9', '26', '1.00', '1', '2019-09-03', '01:43:21', '3');
INSERT INTO `customer_added_item` VALUES('136', '2', '0', '31', '1.00', '0', '2019-09-03', '01:48:14', '5');
INSERT INTO `customer_added_item` VALUES('137', '2', '3', '33', '1.00', '1', '2019-09-03', '01:48:14', '3');
INSERT INTO `customer_added_item` VALUES('138', '2', '2', '4', '1.00', '1', '2019-09-03', '01:48:16', '3');
INSERT INTO `customer_added_item` VALUES('139', '2', '2', '11', '1.00', '1', '2019-09-03', '01:48:17', '3');
INSERT INTO `customer_added_item` VALUES('140', '2', '1', '35', '2.00', '1', '2019-09-03', '01:48:18', '3');
INSERT INTO `customer_added_item` VALUES('141', '2', '1', '9', '1.00', '1', '2019-09-03', '01:48:19', '3');
INSERT INTO `customer_added_item` VALUES('142', '2', '1', '26', '3.00', '1', '2019-09-03', '01:48:20', '3');
INSERT INTO `customer_added_item` VALUES('143', '2', '3', '4', '2.00', '1', '2019-09-03', '02:20:35', '3');
INSERT INTO `customer_added_item` VALUES('144', '2', '4', '5', '2.00', '1', '2019-09-03', '02:20:38', '3');
INSERT INTO `customer_added_item` VALUES('145', '2', '4', '34', '1.00', '1', '2019-09-03', '02:28:34', '3');
INSERT INTO `customer_added_item` VALUES('146', '2', '4', '11', '1.00', '1', '2019-09-03', '02:28:35', '3');
INSERT INTO `customer_added_item` VALUES('147', '2', '7', '35', '1.00', '1', '2019-09-03', '02:28:37', '3');
INSERT INTO `customer_added_item` VALUES('148', '2', '7', '4', '1.00', '1', '2019-09-03', '02:30:59', '3');
INSERT INTO `customer_added_item` VALUES('149', '2', '5', '9', '1.00', '1', '2019-09-03', '02:31:00', '3');
INSERT INTO `customer_added_item` VALUES('150', '2', '5', '22', '1.00', '1', '2019-09-03', '02:31:02', '3');
INSERT INTO `customer_added_item` VALUES('151', '2', '6', '29', '1.00', '1', '2019-09-04', '07:53:48', '3');
INSERT INTO `customer_added_item` VALUES('152', '2', '6', '34', '1.00', '1', '2019-09-04', '07:53:48', '3');


-- Dumping structure for table: `customer_details`

DROP TABLE IF EXISTS `customer_details`;
CREATE TABLE `customer_details` (
  `cus_id` int(10) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `l_name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `city` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `address` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `coustomer_login_status` int(2) DEFAULT NULL,
  `account_status` int(2) DEFAULT '0' COMMENT 'account_status == 0 Active // account_status == 1 Deactive ',
  `reg_date` date DEFAULT NULL,
  `reg_time` time DEFAULT NULL,
  PRIMARY KEY (`cus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: customer_details

INSERT INTO `customer_details` VALUES('1', 'dinesh', 'abe', 'a@gmail.com', 'anamaduwa', 'anamaduwa', '0712484476', '123', '', '0', '2019-08-23', '08:54:01');
INSERT INTO `customer_details` VALUES('2', 'shalu', 'perera', 'b@gmail.com', 'colcomno', 'colombo negambo', '077656565', '123', '', '0', '2019-08-23', '06:41:47');
INSERT INTO `customer_details` VALUES('3', 'Malinda', 'bandara', 'm@gmail.com', '123', 'Ampara', '05556565', '123', '', '0', '2019-08-28', '08:45:05');
INSERT INTO `customer_details` VALUES('6', 'palitha', 'abeysinghe', 'p@gmail.com', 'Thattewa', 'siyambalagashena Road', '0712484476', '123', '', '0', '2019-08-28', '10:28:56');
INSERT INTO `customer_details` VALUES('13', 'hewage', 'abeysinghe', 'h@gmail.com', 'Thattewa', 'siyambalagashena Road', '0712484476', '123', '', '0', '2019-08-28', '11:08:14');
INSERT INTO `customer_details` VALUES('14', 'kasthuri ', 'arachi', 'k@gmail.com', 'k', '2', '065656', '456', '', '0', '2019-08-28', '11:16:23');
INSERT INTO `customer_details` VALUES('15', 'dinesh', 'abeysinghe', 'p@gmail.com', 'Thattewa', 'siyambalagashena Road', '0712484476', '456', '', '0', '2019-08-28', '11:58:06');


-- Dumping structure for table: `in_sysprvlg`

DROP TABLE IF EXISTS `in_sysprvlg`;
CREATE TABLE `in_sysprvlg` (
  `prvCode` int(11) NOT NULL,
  `prvName` varchar(100) NOT NULL,
  `prvStatus` int(3) NOT NULL DEFAULT '1',
  `usrPrvMnuName` varchar(100) NOT NULL,
  `usrPrvMnuName_sinhala` varchar(255) DEFAULT NULL,
  `usrPrvMnuIcon` varchar(45) DEFAULT '',
  `usrPrvMnuPath` varchar(100) NOT NULL,
  `usrPrnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`prvCode`),
  UNIQUE KEY `user_privilage_code` (`prvCode`),
  UNIQUE KEY `user_privilage_code_2` (`prvCode`,`prvName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_sysprvlg

INSERT INTO `in_sysprvlg` VALUES('101', 'User Management', '1', 'User Management', 'User Management', 'usermanege.png', 'user_manegement_view.php', '111');
INSERT INTO `in_sysprvlg` VALUES('102', 'Item Managagement', '1', 'Item Managagement', 'Item Managagement', 'add_cart2.ico', 'item_reg_view.php', '102');
INSERT INTO `in_sysprvlg` VALUES('103', 'Order Information', '1', 'Order Information', 'Order Information', 'add_cart2.ico', 'order_info_view.php', '103');
INSERT INTO `in_sysprvlg` VALUES('200', 'Back Up', '1', 'Back Up', 'Back Up', 'backup.png', 'back_up_view.php', '200');


-- Dumping structure for table: `in_usr`

DROP TABLE IF EXISTS `in_usr`;
CREATE TABLE `in_usr` (
  `usrID` int(11) NOT NULL AUTO_INCREMENT,
  `usrName` varchar(50) NOT NULL DEFAULT '',
  `usrFName` varchar(100) DEFAULT NULL,
  `usrLName` varchar(100) DEFAULT NULL,
  `usrLevel` int(11) NOT NULL DEFAULT '1',
  `usrPwd` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `usrRegDate` date NOT NULL DEFAULT '0000-00-00',
  `usrStatus` int(1) NOT NULL DEFAULT '1',
  `usrAddress` varchar(200) DEFAULT NULL,
  `usrEmail` varchar(150) DEFAULT NULL,
  `lstLgDate` date NOT NULL,
  `lstLgTime` time NOT NULL,
  `usrEmpNo` varchar(100) DEFAULT NULL,
  `usrNIC` varchar(20) DEFAULT NULL,
  `usrMobileNo` varchar(20) DEFAULT NULL,
  `usrWorkTelNo` varchar(20) DEFAULT NULL,
  `usrHomeTelNo` varchar(20) DEFAULT NULL,
  `userBranchID` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrName`),
  UNIQUE KEY `usrEmpNo` (`usrEmpNo`),
  UNIQUE KEY `usrNIC` (`usrNIC`),
  UNIQUE KEY `usrEmpNo_2` (`usrEmpNo`,`usrNIC`),
  KEY `id` (`usrID`),
  KEY `user_level` (`usrLevel`),
  KEY `user_name` (`usrName`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usr

INSERT INTO `in_usr` VALUES('89', 'systemadmin', 'dinesh', 'abeysinghe', '188', '1843fd43ce17a7df90fc1a4db3a63a6cc82c89c1', '2018-12-28', '1', '', '', '2018-12-28', '10:38:33', '66565656', '565656565v', '', '', '', '1');
INSERT INTO `in_usr` VALUES('96', 'nalaka', 'nalaka', 'nawagathegama', '192', '87755fcafa59a5c1b6ecf301bf64d399753098c2', '2019-07-30', '1', 'a', '', '2019-07-30', '12:20:41', '45454', '889898998v', '', '', '', '1');


-- Dumping structure for table: `in_usrlevel`

DROP TABLE IF EXISTS `in_usrlevel`;
CREATE TABLE `in_usrlevel` (
  `lvID` int(11) NOT NULL AUTO_INCREMENT,
  `lvName` varchar(100) DEFAULT NULL,
  `usrLvlPrvSeq` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lvID`),
  UNIQUE KEY `usrLvlPrvSeq` (`usrLvlPrvSeq`),
  UNIQUE KEY `admin_level_name` (`lvName`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlevel

INSERT INTO `in_usrlevel` VALUES('18', 'Super User', '20');
INSERT INTO `in_usrlevel` VALUES('188', 'admin', '1');
INSERT INTO `in_usrlevel` VALUES('192', 'User', '3');


-- Dumping structure for table: `in_usrlvlpriv`

DROP TABLE IF EXISTS `in_usrlvlpriv`;
CREATE TABLE `in_usrlvlpriv` (
  `usrLvl` int(11) NOT NULL,
  `usrPrivilage` int(11) NOT NULL,
  PRIMARY KEY (`usrLvl`,`usrPrivilage`),
  UNIQUE KEY `usrLvl` (`usrLvl`,`usrPrivilage`),
  KEY `usrPrivilage` (`usrPrivilage`),
  CONSTRAINT `in_usrlvlpriv_ibfk_1` FOREIGN KEY (`usrLvl`) REFERENCES `in_usrlevel` (`lvID`) ON UPDATE CASCADE,
  CONSTRAINT `in_usrlvlpriv_ibfk_2` FOREIGN KEY (`usrPrivilage`) REFERENCES `in_sysprvlg` (`prvCode`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlvlpriv



-- Dumping structure for table: `in_usrprvlg`

DROP TABLE IF EXISTS `in_usrprvlg`;
CREATE TABLE `in_usrprvlg` (
  `usrID` int(11) NOT NULL,
  `usrPrvCode` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrPrvCode`),
  UNIQUE KEY `usrID` (`usrID`,`usrPrvCode`),
  KEY `usrPrvCode` (`usrPrvCode`),
  CONSTRAINT `in_usrprvlg_ibfk_1` FOREIGN KEY (`usrID`) REFERENCES `in_usr` (`usrID`) ON UPDATE CASCADE,
  CONSTRAINT `in_usrprvlg_ibfk_2` FOREIGN KEY (`usrPrvCode`) REFERENCES `in_sysprvlg` (`prvCode`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrprvlg

INSERT INTO `in_usrprvlg` VALUES('89', '101');
INSERT INTO `in_usrprvlg` VALUES('89', '102');
INSERT INTO `in_usrprvlg` VALUES('89', '103');
INSERT INTO `in_usrprvlg` VALUES('89', '200');
INSERT INTO `in_usrprvlg` VALUES('96', '102');


-- Dumping structure for table: `item_deatails`

DROP TABLE IF EXISTS `item_deatails`;
CREATE TABLE `item_deatails` (
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `sub_cat_id` int(10) NOT NULL,
  `item_name` varchar(200) COLLATE utf8_bin NOT NULL,
  `item_description` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `item_price` double(10,2) DEFAULT NULL,
  `item_discount` double(10,2) DEFAULT NULL,
  `item_image` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `item_video` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `item_view_status` int(2) DEFAULT '0' COMMENT '0== Active / 1== Diactive',
  `vdo_status` int(1) DEFAULT '0' COMMENT '0 == no video // 1 == availabel vdo',
  `img_status` int(1) DEFAULT '0' COMMENT '0== no img // 1== availabel img',
  PRIMARY KEY (`item_id`),
  KEY `sub_cat_id` (`sub_cat_id`),
  CONSTRAINT `sub_cat_id` FOREIGN KEY (`sub_cat_id`) REFERENCES `sub_cat` (`sub_cat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: item_deatails

INSERT INTO `item_deatails` VALUES('4', '24', 'Bio Vitamin', ' Vitamins', '5000.00', '500.00', '235265.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('5', '3', 'B', '	How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value fro', '7000.00', '500.00', '6 (Custom)93061.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('6', '3', 'Vitamin - C', '	How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value fro', '10000.00', '2000.00', '535699.jpg', '-', '1', '0', '1');
INSERT INTO `item_deatails` VALUES('7', '12', 'Night Cream', 'How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from', '33500.00', '1200.00', '5 (Custom)55375.jpg', '', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('8', '12', 'Face cream', ' Fcae ', '3500.00', '500.00', '2 (Custom)21071.jpg', '', '0', '1', '1');
INSERT INTO `item_deatails` VALUES('9', '3', 'E', 'value from the combo box using jQuery.How Can I get selected text value from', '78989.00', '200.00', '845062.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('10', '3', 'D', '	How Can I get selected text value from the combo box using jQuery.How Can I get selected tlected text value from the combo box using jQuery.How ow Can I get selected text value from', '7500.00', '500.00', '465331.jpg', '-', '1', '0', '1');
INSERT INTO `item_deatails` VALUES('11', '24', 'Natural Vitamin', ' 	How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value fr', '7500.00', '250.00', '479394.jpg', '', '0', '1', '1');
INSERT INTO `item_deatails` VALUES('22', '3', 'A', 's', '7888.00', '444.00', '815741.jpg', '<iframe width=\"727\" height=\"409\" src=\"https://www.youtube.com/embed/_tBZM1sNT9M\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '0', '1', '1');
INSERT INTO `item_deatails` VALUES('24', '12', 'Test', 'e from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the com', '3500.00', '565.00', '228657.jpg', '', '0', '1', '1');
INSERT INTO `item_deatails` VALUES('26', '10', 'Herbs shampoo', '56', '4556.00', '656.00', '861157.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('27', '9', 'Rohypnol A', 'Not vitamin', '10000.00', '5000.00', '814680.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('28', '14', 'Milk Suppliment', 'Supliment', '6000.00', '250.00', '455520.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('29', '6', 'Axiio Oil supliment', 'Suplimen', '7800.00', '2500.00', '491692.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('30', '9', 'Rohypnol B', '5', '78565.00', '55.00', '210737.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('31', '29', 'Net Saree', 'Original net wedding saree', '5000.00', '2500.00', 'wedding-sarees-500x50018331.jpg', '<iframe width=\"727\" height=\"409\" src=\"https://www.youtube.com/embed/52WBAYeBCTc\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '0', '1', '1');
INSERT INTO `item_deatails` VALUES('32', '29', 'Laze saree', 'Laze saree', '15000.00', '0.00', '91zc0CBnbLL52929._UY550_', '-', '1', '0', '1');
INSERT INTO `item_deatails` VALUES('33', '29', 'Gold saree', 'Gold saree', '75000.00', '5000.00', 'EAVM-AxU0AA5Ywn16229.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('34', '24', 'Calcium', 'uery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get se', '5000.00', '200.00', 'calsium81398.jpg', '-', '0', '0', '1');
INSERT INTO `item_deatails` VALUES('35', '3', 'Z', 'How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the combo box using jQuery.How Can I get selected text value from the com', '2500.00', '0.00', '5 (Custom)20176.jpg', '-', '0', '0', '1');


-- Dumping structure for table: `main_cat`

DROP TABLE IF EXISTS `main_cat`;
CREATE TABLE `main_cat` (
  `main_cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `main_cat_name` varchar(200) COLLATE utf8_bin NOT NULL,
  `view_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0== Active / 1== Diactive',
  PRIMARY KEY (`main_cat_id`),
  KEY `main_cat` (`main_cat_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: main_cat

INSERT INTO `main_cat` VALUES('3', 'Bio Treetment', '1');
INSERT INTO `main_cat` VALUES('7', 'Hearbs', '0');
INSERT INTO `main_cat` VALUES('8', 'Vitamin', '0');
INSERT INTO `main_cat` VALUES('9', 'Suppliment ', '0');
INSERT INTO `main_cat` VALUES('15', 'Depressants', '1');
INSERT INTO `main_cat` VALUES('17', 'Stimulants', '1');
INSERT INTO `main_cat` VALUES('21', 'Eye Face cream', '1');
INSERT INTO `main_cat` VALUES('22', 'Saree', '0');


-- Dumping structure for table: `pay_completed_invoice_summary`

DROP TABLE IF EXISTS `pay_completed_invoice_summary`;
CREATE TABLE `pay_completed_invoice_summary` (
  `invoice_id` int(10) NOT NULL AUTO_INCREMENT,
  `shipping_id` int(5) NOT NULL,
  `order_value` double(10,2) NOT NULL,
  `order_discount` double(10,2) NOT NULL,
  `pay_date` date NOT NULL,
  `pay_time` time NOT NULL,
  `pay_status` int(3) NOT NULL DEFAULT '0' COMMENT '0== pending // 2==payment success // -1== canceled // -2 == failed // -3 == chargedback',
  PRIMARY KEY (`invoice_id`),
  KEY `shipping_deatails_shipping_id` (`shipping_id`),
  CONSTRAINT `shipping_deatails_shipping_id` FOREIGN KEY (`shipping_id`) REFERENCES `shipping_details` (`shipping_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: pay_completed_invoice_summary

INSERT INTO `pay_completed_invoice_summary` VALUES('3', '3', '574500.00', '0.00', '2019-08-24', '11:48:22', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('5', '4', '80300.00', '0.00', '2019-08-24', '12:55:55', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('6', '5', '17400.00', '0.00', '2019-08-24', '12:58:36', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('7', '6', '7800.00', '0.00', '2019-08-27', '09:57:52', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('8', '7', '12744.00', '0.00', '2019-08-28', '11:24:32', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('9', '8', '10300.00', '0.00', '2019-08-28', '11:44:41', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('10', '9', '16000.00', '0.00', '2019-08-28', '11:56:36', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('11', '10', '72500.00', '0.00', '2019-08-29', '12:00:43', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('12', '12', '5000.00', '0.00', '2019-09-02', '08:05:10', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('13', '19', '38050.00', '0.00', '2019-09-03', '01:28:13', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('14', '20', '22350.00', '0.00', '2019-09-03', '01:35:25', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('15', '20', '22350.00', '0.00', '2019-09-03', '01:35:45', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('16', '21', '95983.00', '0.00', '2019-09-03', '01:46:41', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('17', '22', '95489.00', '0.00', '2019-09-03', '01:49:59', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('18', '23', '11750.00', '0.00', '2019-09-03', '01:53:23', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('19', '24', '79000.00', '0.00', '2019-09-03', '02:21:35', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('20', '25', '25050.00', '1450.00', '2019-09-03', '02:29:08', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('21', '26', '86233.00', '644.00', '2019-09-03', '06:31:20', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('22', '27', '8700.00', '856.00', '2019-09-03', '06:33:20', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('23', '28', '10100.00', '2700.00', '2019-09-04', '07:54:40', '2');
INSERT INTO `pay_completed_invoice_summary` VALUES('24', '29', '7000.00', '500.00', '2019-09-04', '10:07:44', '2');


-- Dumping structure for table: `pay_completed_item_summary`

DROP TABLE IF EXISTS `pay_completed_item_summary`;
CREATE TABLE `pay_completed_item_summary` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cus_added_item_id` int(10) NOT NULL,
  `item_tot_discount` double(10,2) NOT NULL,
  `item_unit_discount` double(10,2) NOT NULL,
  `item_unit_price` double(10,2) NOT NULL,
  `item_qty` double(10,2) NOT NULL,
  `item_tot_bill_price` double(10,2) NOT NULL,
  `item_pay_date` date NOT NULL,
  `item_pay_time` time NOT NULL,
  `bill_no` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cus_added_item_id` (`cus_added_item_id`),
  CONSTRAINT `cus_added_item_id` FOREIGN KEY (`cus_added_item_id`) REFERENCES `customer_added_item` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: pay_completed_item_summary

INSERT INTO `pay_completed_item_summary` VALUES('1', '131', '250.00', '250.00', '7500.00', '1.00', '7250.00', '2019-09-03', '01:46:41', '8');
INSERT INTO `pay_completed_item_summary` VALUES('2', '132', '0.00', '0.00', '2500.00', '1.00', '2500.00', '2019-09-03', '01:46:41', '8');
INSERT INTO `pay_completed_item_summary` VALUES('3', '133', '444.00', '444.00', '7888.00', '1.00', '7444.00', '2019-09-03', '01:46:41', '8');
INSERT INTO `pay_completed_item_summary` VALUES('4', '134', '200.00', '200.00', '78989.00', '1.00', '78789.00', '2019-09-03', '01:46:41', '8');
INSERT INTO `pay_completed_item_summary` VALUES('5', '140', '0.00', '0.00', '2500.00', '2.00', '5000.00', '2019-09-03', '01:49:59', '1');
INSERT INTO `pay_completed_item_summary` VALUES('6', '141', '200.00', '200.00', '78989.00', '1.00', '78789.00', '2019-09-03', '01:49:59', '1');
INSERT INTO `pay_completed_item_summary` VALUES('7', '142', '1968.00', '656.00', '4556.00', '3.00', '11700.00', '2019-09-03', '01:49:59', '1');
INSERT INTO `pay_completed_item_summary` VALUES('8', '138', '500.00', '500.00', '5000.00', '1.00', '4500.00', '2019-09-03', '01:53:23', '2');
INSERT INTO `pay_completed_item_summary` VALUES('9', '139', '250.00', '250.00', '7500.00', '1.00', '7250.00', '2019-09-03', '01:53:23', '2');
INSERT INTO `pay_completed_item_summary` VALUES('10', '137', '5000.00', '5000.00', '75000.00', '1.00', '70000.00', '2019-09-03', '02:21:35', '3');
INSERT INTO `pay_completed_item_summary` VALUES('11', '143', '1000.00', '500.00', '5000.00', '2.00', '9000.00', '2019-09-03', '02:21:35', '3');
INSERT INTO `pay_completed_item_summary` VALUES('12', '144', '1000.00', '500.00', '7000.00', '2.00', '13000.00', '2019-09-03', '02:29:08', '4');
INSERT INTO `pay_completed_item_summary` VALUES('13', '145', '200.00', '200.00', '5000.00', '1.00', '4800.00', '2019-09-03', '02:29:08', '4');
INSERT INTO `pay_completed_item_summary` VALUES('14', '146', '250.00', '250.00', '7500.00', '1.00', '7250.00', '2019-09-03', '02:29:08', '4');
INSERT INTO `pay_completed_item_summary` VALUES('15', '149', '200.00', '200.00', '78989.00', '1.00', '78789.00', '2019-09-03', '06:31:20', '5');
INSERT INTO `pay_completed_item_summary` VALUES('16', '150', '444.00', '444.00', '7888.00', '1.00', '7444.00', '2019-09-03', '06:31:20', '5');
INSERT INTO `pay_completed_item_summary` VALUES('17', '130', '200.00', '200.00', '5000.00', '1.00', '4800.00', '2019-09-03', '06:33:20', '9');
INSERT INTO `pay_completed_item_summary` VALUES('18', '135', '656.00', '656.00', '4556.00', '1.00', '3900.00', '2019-09-03', '06:33:20', '9');
INSERT INTO `pay_completed_item_summary` VALUES('19', '151', '2500.00', '2500.00', '7800.00', '1.00', '5300.00', '2019-09-04', '07:54:40', '6');
INSERT INTO `pay_completed_item_summary` VALUES('20', '152', '200.00', '200.00', '5000.00', '1.00', '4800.00', '2019-09-04', '07:54:40', '6');
INSERT INTO `pay_completed_item_summary` VALUES('21', '147', '0.00', '0.00', '2500.00', '1.00', '2500.00', '2019-09-04', '10:07:44', '7');
INSERT INTO `pay_completed_item_summary` VALUES('22', '148', '500.00', '500.00', '5000.00', '1.00', '4500.00', '2019-09-04', '10:07:44', '7');


-- Dumping structure for table: `shipping_details`

DROP TABLE IF EXISTS `shipping_details`;
CREATE TABLE `shipping_details` (
  `shipping_id` int(10) NOT NULL AUTO_INCREMENT,
  `cus_id` int(10) NOT NULL,
  `bill_no` int(10) NOT NULL,
  `recipients_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `recipients_phone` varchar(12) COLLATE utf8_bin NOT NULL,
  `shipping_city` varchar(100) COLLATE utf8_bin NOT NULL,
  `shipping_address` varchar(200) COLLATE utf8_bin NOT NULL,
  `user_note` varchar(500) COLLATE utf8_bin NOT NULL,
  `shipping_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0==shipping not complete // 1== shipping complete order // 3 == shipping cancel order',
  `pay_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0== pending // 2==payment success // -1== canceled // -2 == failed // -3 == chargedback',
  `order_value` double(10,2) NOT NULL,
  `order_discount` double(10,2) NOT NULL,
  `order_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0==not complete // 1== complete order // 3 == cancel order',
  PRIMARY KEY (`shipping_id`),
  KEY `cus_deatails_cus_id` (`cus_id`),
  CONSTRAINT `cus_deatails_cus_id` FOREIGN KEY (`cus_id`) REFERENCES `customer_details` (`cus_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: shipping_details

INSERT INTO `shipping_details` VALUES('3', '1', '1', 'Chalu', '0765656', 'Kandy', 'Anama', '2', '0', '2', '574500.00', '40500.00', '0');
INSERT INTO `shipping_details` VALUES('4', '1', '2', 'Chanaka', '0778988998', 'Kandy', 'Ampara road kalaniya', 'Neeg Good one', '0', '2', '80300.00', '8812.00', '0');
INSERT INTO `shipping_details` VALUES('5', '1', '3', 'Prasadini', '0712484479', 'anama', 'Kandy,kurunegala', 'No', '0', '2', '17400.00', '2156.00', '0');
INSERT INTO `shipping_details` VALUES('6', '1', '4', 'Chamari ', '07787888', 'anama', 'Kandy road kurunegala ,No 33 Ampara', 'This is important order', '0', '2', '7800.00', '1312.00', '0');
INSERT INTO `shipping_details` VALUES('7', '14', '1', 'Chamarika', '07798989', 'anama', 'siyambalagashena Road\nKadurugas Junction,', 'New order', '0', '2', '12744.00', '2944.00', '0');
INSERT INTO `shipping_details` VALUES('8', '14', '2', 'chanaka', '056556', '-', 'Ampara', 'k', '0', '2', '10300.00', '7500.00', '0');
INSERT INTO `shipping_details` VALUES('9', '14', '3', 'Prasada', '0778856565', '-', 'Siyambalanduwa kotte 123', '1', '0', '2', '16000.00', '3556.00', '0');
INSERT INTO `shipping_details` VALUES('10', '15', '1', 'palitha', '07489898', '-', 'Kobaigane ,wariyapola 3310', ';', '0', '2', '72500.00', '7500.00', '0');
INSERT INTO `shipping_details` VALUES('11', '15', '0', 'Palitha', '0784546422', '-', '2654 Homagama', '2222', '0', '0', '0.00', '0.00', '0');
INSERT INTO `shipping_details` VALUES('12', '1', '5', 'kasthuri', '077799', '-', 'Kandy', 's', '0', '2', '5000.00', '5000.00', '0');
INSERT INTO `shipping_details` VALUES('19', '1', '6', 'Chaluka Mahendra', '077989898', '-', 'walisara roar , no 33 kaduwala', '', '0', '2', '38050.00', '2450.00', '0');
INSERT INTO `shipping_details` VALUES('20', '1', '7', 'Inoshika Herath Aberathna', '0784579859', '-', 'siyambalagashena Road\nKadurugas Junction,', '', '0', '2', '22350.00', '5750.00', '0');
INSERT INTO `shipping_details` VALUES('21', '1', '8', 'Chalika Somasiri', '0714587524', '-', 'Maharagama road kaluthara', '', '0', '2', '95983.00', '894.00', '0');
INSERT INTO `shipping_details` VALUES('22', '2', '1', 'Shalu Perera', '0778944562', '-', 'siyambalagashena Road\nKadurugas Junction,Thattewa Anamaduwa', '', '0', '2', '95489.00', '2168.00', '0');
INSERT INTO `shipping_details` VALUES('23', '2', '2', 'Palitha', '07885656', '-', 'Mahanuwara , Kandy Road 3310', '', '0', '2', '11750.00', '750.00', '0');
INSERT INTO `shipping_details` VALUES('24', '2', '3', 'hampika', '077656', '-', 'aaa', '', '0', '2', '79000.00', '6000.00', '0');
INSERT INTO `shipping_details` VALUES('25', '2', '4', 'MAhinda ', '07765545', '-', 'Anamaduwa', '', '0', '2', '0.00', '0.00', '0');
INSERT INTO `shipping_details` VALUES('26', '2', '5', 'chathu', '0784589789', '-', 'siyambalagashena Road\nKadurugas Junction,', '', '0', '2', '0.00', '0.00', '0');
INSERT INTO `shipping_details` VALUES('27', '1', '9', 'MAhesh', '07145878654', '-', 'siyambalagashena Road\nKadurugas Junction,', '', '1', '2', '0.00', '0.00', '0');
INSERT INTO `shipping_details` VALUES('28', '2', '6', 'Mahesh', '0714587789', '-', 'siyambalagashena Road\nKadurugas Junction,', '', '1', '2', '0.00', '0.00', '0');
INSERT INTO `shipping_details` VALUES('29', '2', '7', 'Madumali', '0714589556', '-', 'Ampara kobaigane', 'No', '1', '2', '0.00', '0.00', '0');


-- Dumping structure for table: `shipping_method`

DROP TABLE IF EXISTS `shipping_method`;
CREATE TABLE `shipping_method` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `shipping_method` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: shipping_method

INSERT INTO `shipping_method` VALUES('1', 'Post order');
INSERT INTO `shipping_method` VALUES('2', 'Shippin Company');


-- Dumping structure for table: `shipping_order_list`

DROP TABLE IF EXISTS `shipping_order_list`;
CREATE TABLE `shipping_order_list` (
  `shipping_order_id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) NOT NULL,
  `poste_date` date NOT NULL,
  `poste_time` time NOT NULL,
  `dilivery_method` int(10) NOT NULL,
  `order_complete_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0==shipping not complete // 1== shipping complete order // 3 == shipping cancel order',
  PRIMARY KEY (`shipping_order_id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `pay_cmplet_invo_smry_id` FOREIGN KEY (`invoice_id`) REFERENCES `pay_completed_invoice_summary` (`invoice_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: shipping_order_list

INSERT INTO `shipping_order_list` VALUES('2', '3', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('4', '5', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('5', '6', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('6', '7', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('7', '8', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('8', '9', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('9', '10', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('10', '11', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('11', '12', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('12', '13', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('13', '14', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('14', '15', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('15', '16', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('16', '17', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('17', '18', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('18', '19', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('19', '20', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('20', '21', '0000-00-00', '00:00:00', '0', '0');
INSERT INTO `shipping_order_list` VALUES('21', '22', '2019-09-04', '09:48:20', '2', '1');
INSERT INTO `shipping_order_list` VALUES('22', '23', '0000-00-00', '00:00:00', '2', '1');
INSERT INTO `shipping_order_list` VALUES('23', '24', '0000-00-00', '00:00:00', '1', '1');


-- Dumping structure for table: `sub_cat`

DROP TABLE IF EXISTS `sub_cat`;
CREATE TABLE `sub_cat` (
  `sub_cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `main_cat_id` int(10) NOT NULL,
  `sub_cat_name` varchar(200) COLLATE utf8_bin NOT NULL,
  `view_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0== Active / 1== Diactive',
  PRIMARY KEY (`sub_cat_id`),
  KEY `main_cat_id` (`main_cat_id`),
  CONSTRAINT `main_cat` FOREIGN KEY (`main_cat_id`) REFERENCES `main_cat` (`main_cat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: sub_cat

INSERT INTO `sub_cat` VALUES('1', '9', 'Green Tea Extract', '1');
INSERT INTO `sub_cat` VALUES('2', '9', 'Fiber & Prebiotics ', '1');
INSERT INTO `sub_cat` VALUES('3', '8', 'Later Vitamin', '0');
INSERT INTO `sub_cat` VALUES('4', '3', 'Bio vta', '0');
INSERT INTO `sub_cat` VALUES('5', '9', 'Bee Products ', '1');
INSERT INTO `sub_cat` VALUES('6', '9', 'Aloe x', '0');
INSERT INTO `sub_cat` VALUES('7', '15', 'Benziodiazepines', '0');
INSERT INTO `sub_cat` VALUES('8', '15', 'Valium', '0');
INSERT INTO `sub_cat` VALUES('9', '15', 'Rohypnol', '0');
INSERT INTO `sub_cat` VALUES('10', '7', 'herbz', '0');
INSERT INTO `sub_cat` VALUES('11', '9', 'Amino Acids Upaaa', '1');
INSERT INTO `sub_cat` VALUES('12', '21', 'Natural Cream ', '0');
INSERT INTO `sub_cat` VALUES('13', '17', 'Ritalin', '0');
INSERT INTO `sub_cat` VALUES('14', '17', 'Adderall', '0');
INSERT INTO `sub_cat` VALUES('24', '8', 'Multi Vitamins', '0');
INSERT INTO `sub_cat` VALUES('28', '21', 'Face white cream', '0');
INSERT INTO `sub_cat` VALUES('29', '22', 'Wedding Saree', '0');


-- Dumping structure for table: `web_cart`

DROP TABLE IF EXISTS `web_cart`;
CREATE TABLE `web_cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `item_id` int(2) DEFAULT NULL,
  `item_qty` int(10) DEFAULT NULL,
  `item_price` double(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_key` (`user_key`,`item_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- Dumping data for table: web_cart



SET FOREIGN_KEY_CHECKS=1; 

