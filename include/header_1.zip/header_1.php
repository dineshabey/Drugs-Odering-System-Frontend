

<title>Lionvitamin</title>


<!--//theme-style-->
<!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">-->
<!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">-->
<!--<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">-->

<!--<meta name="viewport" content="width=600">-->


 <!--Anuja meta tag-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">


<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	

      <!-- font awesome -->
        <link rel="stylesheet" href="css/font-awesome.min.css">

        <!-- google fonts -->
        <link href="https://fonts.googleapis.com/css?family=Libre+Franklin:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet"> 

        <!-- custom css -->
        <link rel="stylesheet" type="text/css" href="css/lion-style.css">


<!--GOOGLE TRANSLATE--////////////////////////////////////////////////////////>-->

<!--MENU CSSS START******************************************-->
<link href="jquery_menu/css/sm-core-css.css" rel="stylesheet" type="text/css" />
<link href="jquery_menu/css/sm-blue/sm-blue.css" rel="stylesheet" type="text/css" />
<!--MENU CSSS END   ******************************************-->

<!--NEW MENU NAV BAR CSS END   ====================================================-->

<link rel="stylesheet" type="text/css" href="./slick/slick.css">
<link rel="stylesheet" type="text/css" href="./slick/slick-theme.css">



<link href="js/AlertifyJS-master/build/css/themes/default.css" rel="stylesheet" type="text/css"/>
<link href="js/AlertifyJS-master/build/css/alertify.min.css" rel="stylesheet" type="text/css"/>


<link rel="stylesheet"  href= "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 

<!--<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>-->
<!--fonts-->
<!--<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>-->
<!--//fonts-->
<script src="js/jquery.min.js"></script>
<!--script-->

<!--GOOGLE TRANSALATE JS //////////////////////////////////////////////-->
<!--<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>-->
<!--GOOGLE TRANSALATE JS //////////////////////////////////////////////-->

<!--GOOGLE TRANSLATE--////////////////////////////////////////////////////////>-->
<script type="text/javascript">
//    function googleTranslateElementInit() {
//        new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
//    }
</script>

<script src="js/AlertifyJS-master/build/alertify.min.js" type="text/javascript"></script>
<a href="fonts/user-solid.svg"></a>
<script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>




<style type="text/css">

    @media screen and (max-width: 600px){
        .font_size_mobil {
            color: red !important;
            font-size: 80px !important;
        }
    }

    
     .bottom_head_cus {
                background-image: url("images/site_img/green_bac5.jpg") !important;
                -webkit-background-size: cover !important;
                -moz-background-size: cover !important;
                -o-background-size: cover !important;
                background-size: cover !important;

            }

            .top_head_cus2 {
                background-image: url("images/site_img/gold_bac.jpg") !important;
                border-bottom: 1px solid #fff !important;
                /*padding: 1.9em 0;*/
            }
            .top_head_cus {
                background-image: url("images/site_img/slide6.jpg") !important;
                /*background-image: url("images/site_img/green_bac5.jpg") !important;*/
                -webkit-background-size: cover !important;
                -moz-background-size: cover !important;
                -o-background-size: cover !important;
                background-size: cover !important;
                /*padding: 1.9em 0;*/
            }

            .lion_text{
                /*text-shadow: 0 4px 0 #000,  0 3px 0 #0e0c0c, 0 4px 0 #b9b9b9, 0 5px 0 #aaa, 0 6px 1px #9bbaeca1, 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15);*/
                font-weight: 600;
                text-shadow: 0 -2px 0 black, 
                    /*0 2px 0 #c9c9c9,*/
                    5px 4px 6px black,
                    0 4px 0 black,
                    0 4px 0 blue,
                    0 5px 0 blue,
                    0 6px 1px rgba(300,100,300),
                    0 0 5px rgba(105,100,300),
                    0 1px 3px rgba(105,100,300),
                    0 3px 5px rgba(105,500,300),
                    0 5px 10px rgba(105,105,300),
                    0 10px 10px rgba(105,105,300),
                    0 20px 20px rgba(105,300,200);
                font-size: 40px;
                color: #ffff59; 
            }
            .logon_pnl:hover {
                color: white;
            }
    
    
</style>